/**
 * 
 */
package peersim.chord;

/**
 * @author Andrea
 * 
 */
public interface ChordMessage {

}
