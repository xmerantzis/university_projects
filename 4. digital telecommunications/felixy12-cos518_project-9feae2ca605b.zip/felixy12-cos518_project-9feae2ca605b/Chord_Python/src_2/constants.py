ring_size = 10
max_offset = 100
successor_list_size = 5 #This is r in the paper

stabilize_period = max_offset * 2 
fix_finger_period = max_offset
check_pred_period = max_offset * 3
